# Trendy Wear BD — Android Studio WebView Project

This project wraps the supplied `index.html` in a native Android WebView.

## Important
- The supplied `index.html` is copied byte-for-byte into:
  `app/src/main/assets/index.html`
- No HTML, CSS, JavaScript, UI structure, or site functionality was modified.
- The native wrapper only provides the Android shell, WebView, Internet access, file chooser, external links, and back navigation.
- Internet access is required because the HTML loads Firebase and other remote resources.

## Build in Android Studio
1. Open Android Studio.
2. Choose **Open** and select this `TrendyWearBD` folder.
3. Let Gradle sync/download the Android Gradle Plugin and dependencies.
4. Connect an Android phone or create an emulator.
5. Select the `app` run configuration.
6. Press **Run** to install the debug APK.
7. For a release APK: **Build → Generate Signed App Bundle / APK → APK**.

## Package
`com.trendywearbd.app`

## App name
`Trendy Wear BD`

## If Android Studio asks to update Gradle/AGP
Keep the project versions initially. If Android Studio recommends a compatible upgrade, accepting its standard compatible upgrade is normally fine; do not edit `index.html`.
